from django.apps import AppConfig


class CommonConfig(AppConfig):
    name = 'apps.common'
    verbose_name = '公共表'
