from django.apps import AppConfig


class ArticleConfig(AppConfig):
    name = 'apps.article'
    verbose = '文章表'
